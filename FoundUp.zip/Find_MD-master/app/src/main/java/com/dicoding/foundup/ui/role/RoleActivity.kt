package com.dicoding.foundup.ui.role

import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dicoding.foundup.R

@Suppress("DEPRECATION")
class RoleActivity : AppCompatActivity() {

    private lateinit var ownerButton: Button
    private lateinit var techWorkerButton: Button
    private lateinit var nextButton: Button

    private var selectedRole: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_role)

        // Inisialisasi Views
        ownerButton = findViewById(R.id.ownerButton)
        techWorkerButton = findViewById(R.id.techWorkerButton)
        nextButton = findViewById(R.id.nextButton)

        // Atur logika pemilihan
        ownerButton.setOnClickListener {
            updateSelection("Owner")
        }

        techWorkerButton.setOnClickListener {
            updateSelection("Tech Worker")
        }
    }

    private fun updateSelection(role: String) {
        selectedRole = role // Update pilihan yang dipilih

        // Atur tampilan tombol agar hanya satu yang terpilih
        when (role) {
            "Owner" -> {
                ownerButton.setBackgroundColor(resources.getColor(R.color.purple_500))
                ownerButton.setTextColor(resources.getColor(R.color.white))
                techWorkerButton.setBackgroundColor(resources.getColor(R.color.white))
                techWorkerButton.setTextColor(resources.getColor(R.color.purple_500))
            }
            "Tech Worker" -> {
                techWorkerButton.setBackgroundColor(resources.getColor(R.color.purple_500))
                techWorkerButton.setTextColor(resources.getColor(R.color.white))
                ownerButton.setBackgroundColor(resources.getColor(R.color.white))
                ownerButton.setTextColor(resources.getColor(R.color.purple_500))
            }
        }


        nextButton.isEnabled = true
        nextButton.setBackgroundColor(resources.getColor(R.color.purple_700))
    }
}